[![Build Status](https://gitlab.gnome.org/GNOME/gnome-calculator/badges/master/build.svg)](https://gitlab.gnome.org/GNOME/gnome-calculator/pipelines)

This is the source code for the standard GNOME calculator.
